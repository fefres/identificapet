# Guía de Imágenes para AdoptaIA

Este directorio debe contener las siguientes imágenes para que la página web funcione correctamente:

## Imágenes Requeridas

### 1. favicon.svg (YA CREADO)
- **Tamaño**: 32x32px
- **Formato**: SVG
- **Descripción**: Logo de AdoptaIA
- **Estado**: ✅ Creado

### 2. hero-dog.jpg
- **Tamaño recomendado**: 1200x800px
- **Formato**: JPG o WebP
- **Descripción**: Imagen principal del hero section mostrando mascotas felices
- **Uso**: Sección principal de la página
- **Estado**: ❌ Pendiente

### 3. pet1.jpg
- **Tamaño recomendado**: 400x300px
- **Formato**: JPG o WebP
- **Descripción**: Foto de Luna (perra mestiza, 2 años)
- **Uso**: Tarjeta de mascota destacada #1
- **Estado**: ❌ Pendiente

### 4. pet2.jpg
- **Tamaño recomendado**: 400x300px
- **Formato**: JPG o WebP
- **Descripción**: Foto de Max (gato siamés, 1 año)
- **Uso**: Tarjeta de mascota destacada #2
- **Estado**: ❌ Pendiente

### 5. pet3.jpg
- **Tamaño recomendado**: 400x300px
- **Formato**: JPG o WebP
- **Descripción**: Foto de Bella (perra labrador, 4 años)
- **Uso**: Tarjeta de mascota destacada #3
- **Estado**: ❌ Pendiente

## Cómo Obtener las Imágenes

### Opción 1: Usar Imágenes de Stock Gratuitas
- **Unsplash**: https://unsplash.com (buscar "happy dogs", "cute cats")
- **Pexels**: https://pexels.com (imágenes gratuitas de mascotas)
- **Pixabay**: https://pixabay.com (fotos e ilustraciones gratuitas)

### Opción 2: Usar Generadores de Imágenes
- **DALL-E**: https://openai.com/dall-e
- **Midjourney**: https://midjourney.com
- **Stable Diffusion**: https://stability.ai

### Opción 3: Crear Imágenes SVG Personalizadas
Puedes crear imágenes SVG simples que mantengan el diseño limpio:

```svg
<svg width="400" height="300" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
  <rect width="400" height="300" fill="#f3f4f6"/>
  <circle cx="200" cy="150" r="50" fill="#6b7280"/>
  <text x="200" y="155" font-family="Arial" font-size="16" fill="white" text-anchor="middle">MASCOTA</text>
</svg>
```

## Optimización de Imágenes

### Para GitHub Pages, asegúrate de:
1. **Comprimir las imágenes** antes de subirlas
2. **Usar formatos modernos** como WebP cuando sea posible
3. **Optimizar el tamaño** sin perder calidad visual
4. **Incluir texto alternativo** descriptivo en el HTML

### Herramientas Recomendadas:
- **TinyPNG**: https://tinypng.com (compresión)
- **Squoosh**: https://squoosh.app (optimización)
- **ImageOptim**: Para Mac

## Estructura de Archivos Final

```
images/
├── favicon.svg          # ✅ Ya creado
├── hero-dog.jpg         # ❌ Necesita ser añadido
├── pet1.jpg            # ❌ Necesita ser añadido  
├── pet2.jpg            # ❌ Necesita ser añadido
└── pet3.jpg            # ❌ Necesita ser añadido
```

## Instrucciones de Implementación

1. **Descarga o crea las 4 imágenes faltantes**
2. **Nómbralas exactamente** como se especifica arriba
3. **Colócalas en la carpeta `images/`**
4. **Sube todo el directorio** a tu repositorio de GitHub

Una vez añadidas las imágenes, tu página web estará completamente funcional con contenido visual atractivo.